# Bomb Rush Cyberfunk VR

Adds VR support for the game, third and first person view.
Game fully playable in VR.

## Features

- Third person view, just like the original game
- First person view with two levels of immersion, basic and full immersive
- Gamepad controls in third person view
- VR controllers supported in first person view

## Install

Install with mod manager or manual download the zip and extract its content in the game root folder.

## Controls

![Several players in a Slop Crew server](https://i.ibb.co/YBW0KCG/VRControls.jpg)

Using GAMEPAD, hold the start button to recenter view.</br>
Using VR controls, click and hold Left Joystick to recenter view

## Config

```
## Settings file was created by plugin BombRushCyberFunk_VR v1.0.0
## Plugin GUID: BombRushCyberFunk_VR

[General]

## First person mode with VR hands and VR controller support
# Setting type: Boolean
# Default value: false
firstPerson = false

## !! Requires firstPerson = true !! First person mode with full ingame head movements, need strong VR legs
# Setting type: Boolean
# Default value: false
fullImmersive = false

```
This file is created after the first launch of the game with this mod, at **BepInEx/config/BombRushCyberFunk_VR.cfg**</br>
Edit this file and turn "firstPerson = false" to "firstPerson = **true**" to activate first person view and VR controls.